package com.example.orderbot

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ---------- مدل و دیتابیس ----------
data class Order(
    val id: Long, val name: String, val phone: String, val item: String,
    val qty: Int, val note: String, val status: Int, val created: Long
)

val STATUSES = listOf("جدید", "در حال انجام", "تحویل شد")

class Db(ctx: Context) : SQLiteOpenHelper(ctx, "orders.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, " +
                "item TEXT, qty INTEGER, note TEXT, status INTEGER, created INTEGER)"
        )
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun insert(name: String, phone: String, item: String, qty: Int, note: String) {
        val v = ContentValues().apply {
            put("name", name); put("phone", phone); put("item", item)
            put("qty", qty); put("note", note); put("status", 0)
            put("created", System.currentTimeMillis())
        }
        writableDatabase.insert("orders", null, v)
    }

    fun all(): List<Order> {
        val list = mutableListOf<Order>()
        readableDatabase.rawQuery("SELECT * FROM orders ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) {
                list += Order(
                    c.getLong(0), c.getString(1), c.getString(2), c.getString(3),
                    c.getInt(4), c.getString(5), c.getInt(6), c.getLong(7)
                )
            }
        }
        return list
    }

    fun setStatus(id: Long, status: Int) {
        writableDatabase.update("orders", ContentValues().apply { put("status", status) }, "id=?", arrayOf(id.toString()))
    }

    fun delete(id: Long) {
        writableDatabase.delete("orders", "id=?", arrayOf(id.toString()))
    }
}

// ---------- اکتیویتی ----------
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Db(this)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) {}
                .launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme { Surface(Modifier.fillMaxSize()) { App(db) } }
            }
        }
    }
}

@Composable
fun App(db: Db) {
    var tab by remember { mutableIntStateOf(0) }
    var orders by remember { mutableStateOf(db.all()) }
    fun refresh() { orders = db.all() }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("سفارش جدید") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("سفارش‌ها (${orders.size})") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("زمان‌بندی") })
        }
        if (tab == 0) {
            OrderForm(onSubmit = { n, p, i, q, note ->
                db.insert(n, p, i, q, note); refresh(); tab = 1
            })
        } else if (tab == 1) {
            OrderList(orders, db, ::refresh)
        } else {
            TasksScreen()
        }
    }
}

@Composable
fun OrderForm(onSubmit: (String, String, String, Int, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var item by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        OutlinedTextField(name, { name = it }, label = { Text("نام مشتری") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(
            phone, { phone = it }, label = { Text("شماره تماس") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )
        OutlinedTextField(item, { item = it }, label = { Text("محصول / خدمت") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        OutlinedTextField(
            qty, { qty = it.filter(Char::isDigit) }, label = { Text("تعداد") }, modifier = Modifier.fillMaxWidth(),
            singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
        )
        OutlinedTextField(note, { note = it }, label = { Text("توضیحات (اختیاری)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        Button(
            onClick = {
                val q = qty.toIntOrNull() ?: 0
                if (name.isBlank() || phone.isBlank() || item.isBlank() || q < 1) {
                    error = "نام، شماره، محصول و تعداد را کامل وارد کنید."
                } else {
                    onSubmit(name.trim(), phone.trim(), item.trim(), q, note.trim())
                    name = ""; phone = ""; item = ""; qty = "1"; note = ""; error = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("ثبت سفارش") }
    }
}

@Composable
fun OrderList(orders: List<Order>, db: Db, refresh: () -> Unit) {
    val ctx = LocalContext.current
    if (orders.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("هنوز سفارشی ثبت نشده") }
        return
    }
    val fmt = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }
    LazyColumn(
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(orders, key = { it.id }) { o ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("${o.item} × ${o.qty}", style = MaterialTheme.typography.titleMedium)
                    Text("${o.name} - ${o.phone}")
                    if (o.note.isNotBlank()) Text(o.note, style = MaterialTheme.typography.bodySmall)
                    Text(fmt.format(Date(o.created)), style = MaterialTheme.typography.bodySmall)
                    Text("وضعیت: ${STATUSES[o.status]}", color = MaterialTheme.colorScheme.primary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (o.status < STATUSES.size - 1) {
                            FilledTonalButton(onClick = { db.setStatus(o.id, o.status + 1); refresh() }) {
                                Text(STATUSES[o.status + 1])
                            }
                        }
                        OutlinedButton(onClick = {
                            val text = "سفارش جدید\nمشتری: ${o.name}\nتلفن: ${o.phone}\n" +
                                "محصول: ${o.item}\nتعداد: ${o.qty}\nتوضیحات: ${o.note}"
                            val i = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text)
                            }
                            ctx.startActivity(Intent.createChooser(i, "ارسال سفارش"))
                        }) { Text("ارسال") }
                        TextButton(onClick = { db.delete(o.id); refresh() }) { Text("حذف") }
                    }
                }
            }
        }
    }
}
