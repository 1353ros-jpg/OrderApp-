package com.example.orderbot

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Build
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import java.util.Calendar

const val FOOD_URL = "https://res.refahgostar.com/mashhad/login.php?type=organizational"
const val STOCK_URL = "https://m.easytrader.ir"
const val CHANNEL_ID = "scheduled_orders"

// ---------- مدل و دیتابیس وظایف ----------
data class Task(
    val id: Long, val kind: Int, val label: String,
    val hour: Int, val minute: Int, val enabled: Boolean
)

class TaskDb(ctx: Context) : SQLiteOpenHelper(ctx, "tasks.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, kind INTEGER, label TEXT, " +
                "hour INTEGER, minute INTEGER, enabled INTEGER)"
        )
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun add(kind: Int, label: String, hour: Int, minute: Int): Task {
        val v = ContentValues().apply {
            put("kind", kind); put("label", label); put("hour", hour); put("minute", minute); put("enabled", 1)
        }
        val id = writableDatabase.insert("tasks", null, v)
        return Task(id, kind, label, hour, minute, true)
    }

    fun all(): List<Task> {
        val l = mutableListOf<Task>()
        readableDatabase.rawQuery("SELECT * FROM tasks ORDER BY hour, minute", null).use { c ->
            while (c.moveToNext()) {
                l += Task(c.getLong(0), c.getInt(1), c.getString(2), c.getInt(3), c.getInt(4), c.getInt(5) == 1)
            }
        }
        return l
    }

    fun setEnabled(id: Long, e: Boolean) {
        writableDatabase.update("tasks", ContentValues().apply { put("enabled", if (e) 1 else 0) }, "id=?", arrayOf(id.toString()))
    }

    fun delete(id: Long) { writableDatabase.delete("tasks", "id=?", arrayOf(id.toString())) }
}

// ---------- زمان‌بندی ----------
object Scheduler {
    private fun pending(ctx: Context, t: Task): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java).apply {
            putExtra("id", t.id); putExtra("kind", t.kind); putExtra("label", t.label)
            putExtra("hour", t.hour); putExtra("minute", t.minute)
        }
        return PendingIntent.getBroadcast(
            ctx, t.id.toInt(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(ctx: Context, t: Task) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, t.hour); set(Calendar.MINUTE, t.minute)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        if (cal.timeInMillis <= System.currentTimeMillis() + 1000) cal.add(Calendar.DAY_OF_YEAR, 1)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, t)
        if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        } else {
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pi)
        }
    }

    fun cancel(ctx: Context, t: Task) {
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx, t))
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val t = Task(
            intent.getLongExtra("id", 0), intent.getIntExtra("kind", 0),
            intent.getStringExtra("label") ?: "", intent.getIntExtra("hour", 0),
            intent.getIntExtra("minute", 0), true
        )
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "یادآور سفارش", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val open = Intent(ctx, WebActivity::class.java).apply {
            putExtra("url", if (t.kind == 0) FOOD_URL else STOCK_URL)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val pi = PendingIntent.getActivity(
            ctx, t.id.toInt(), open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = if (t.kind == 0) "وقت ثبت سفارش غذا" else "وقت ثبت سفارش سهام"
        nm.notify(
            t.id.toInt(),
            NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(t.label)
                .setStyle(NotificationCompat.BigTextStyle().bigText(t.label))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build()
        )
        Scheduler.schedule(ctx, t) // تکرار برای فردا
    }
}

// ---------- مرورگر داخلی (نشست ورود حفظ می‌شود) ----------
class WebActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.loadUrl(intent.getStringExtra("url") ?: FOOD_URL)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush()
    }
}

// ---------- صفحه‌ی زمان‌بندی ----------
@Composable
fun TasksScreen() {
    val ctx = LocalContext.current
    val db = remember { TaskDb(ctx) }
    var tasks by remember { mutableStateOf(db.all()) }
    var kind by remember { mutableIntStateOf(0) }
    var label by remember { mutableStateOf("") }
    var hh by remember { mutableStateOf("") }
    var mm by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("یادآور زمان‌دار", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = kind == 0, onClick = { kind = 0 }); Text("غذا")
            Spacer(Modifier.width(16.dp))
            RadioButton(selected = kind == 1, onClick = { kind = 1 }); Text("سهام")
        }
        OutlinedTextField(
            label, { label = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text(if (kind == 0) "یادداشت (مثلاً ناهار فردا، غذای یارانه‌ای)" else "یادداشت (مثلاً خرید رهیاب، ۵۰۰۰ سهم، قیمت ۷۱۸۰)") },
            minLines = 2
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                hh, { hh = it.filter(Char::isDigit).take(2) }, label = { Text("ساعت (۰ تا ۲۳)") },
                modifier = Modifier.weight(1f), singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
            OutlinedTextField(
                mm, { mm = it.filter(Char::isDigit).take(2) }, label = { Text("دقیقه") },
                modifier = Modifier.weight(1f), singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
            )
        }
        if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)
        Button(
            onClick = {
                val h = hh.toIntOrNull(); val m = mm.toIntOrNull()
                if (h == null || m == null || h !in 0..23 || m !in 0..59) {
                    err = "ساعت و دقیقه را درست وارد کنید."
                } else {
                    val t = db.add(kind, label.trim(), h, m)
                    Scheduler.schedule(ctx, t)
                    tasks = db.all(); label = ""; hh = ""; mm = ""; err = ""
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("افزودن یادآور روزانه") }

        HorizontalDivider()
        if (tasks.isEmpty()) Text("هنوز یادآوری تنظیم نشده")
        tasks.forEach { t ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            "%s - %02d:%02d".format(if (t.kind == 0) "غذا" else "سهام", t.hour, t.minute),
                            style = MaterialTheme.typography.titleSmall
                        )
                        if (t.label.isNotBlank()) Text(t.label, style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = t.enabled, onCheckedChange = { on ->
                        db.setEnabled(t.id, on)
                        if (on) Scheduler.schedule(ctx, t) else Scheduler.cancel(ctx, t)
                        tasks = db.all()
                    })
                    TextButton(onClick = {
                        Scheduler.cancel(ctx, t); db.delete(t.id); tasks = db.all()
                    }) { Text("حذف") }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(ctx, WebActivity::class.java).putExtra("url", FOOD_URL))
            }) { Text("باز کردن سامانه غذا") }
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(ctx, WebActivity::class.java).putExtra("url", STOCK_URL))
            }) { Text("ایزی‌تریدر") }
        }
    }
}
